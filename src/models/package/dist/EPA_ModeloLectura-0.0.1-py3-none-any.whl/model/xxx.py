# from config.core import config
# from pipeline import epa_modelo_lectura_pipe
# from processing.data_manager import load_dataset, save_pipeline
from sklearn.model_selection import train_test_split
import pandas as pd

# data = load_dataset(file_name=config.app_config.data_file)
data = pd.read_csv("C:\package\model\datasets\EXA_2022_1_Todos_Limp.csv")

# divide train and test
X_train, X_test, y_train, y_test = train_test_split(
    data[['ESTU_GRADO', 'COLE_COD_ICFES', 'COLE_COD_MCPIO', 'COLE_COD_DPTO', 'EXA_N_RTAS_CORR_CN', 'EXA_N_RTAS_CORR_CC', 'EXA_N_RTAS_CORR_MT']],  # predictors
    data['EXA_N_RTAS_CORR_LC'],
    test_size=0.33,
    # we are setting the random seed here
    # for reproducibility
    random_state=42,
)

# y_train = y_train.map(config.model_config.qual_mappings)
print(y_train)

# # fit model
# epa_modelo_lectura_pipe.fit(X_train, y_train)

# # persist trained model
# # save_pipeline(pipeline_to_persist=epa_modelo_lectura_pipe)